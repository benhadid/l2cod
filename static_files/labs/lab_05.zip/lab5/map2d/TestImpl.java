import java.util.*;  
import org.junit.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class TestImpl {


     int[] list2array(int head, int capacity)
     {
       List<Integer> nodes = new ArrayList<Integer>();  

       int[] array         = new int[capacity];

       int node = head;
       while(node != 0)
       {
         nodes.add(0, node);

         node = getWord(node + 8);
       }

       int i = 0;

       for(int inode:nodes)
       {
         int array_ptr  = getWord(inode);
         int array_size = getWord(inode + 4);

         for(int j = 0 ; j <array_size; ++j)
         {
                array[i] = getWord(array_ptr);
             
		array_ptr += 4;
                i++;
         }
       }

       return array;
     }
/*
    @Test
    public void map_square() {

        run("jmain", 0); // square function

        int[] expected = {81, 64, 49, 36, 25, 16, 9, 4, 1, 0};

        int head   = get(v0);
        int[] observed = list2array(head);

        Assert.assertArrayEquals(expected, observed);
    }

    @Test
    public void map_double() {

        run("jmain", 1); // double function

        int[] expected = {18, 16, 14, 12, 10, 8, 6, 4, 2, 0};

        int head   = get(v0);
        int[] observed = list2array(head);

        Assert.assertArrayEquals(expected, observed);
    }

    @Test
    public void map_half() {

        run("jmain", 2); // half function

        int[] expected = {4, 4, 3, 3, 2, 2, 1, 1, 0, 0};
 
        int head   = get(v0);
        int[] observed = list2array(head);

        Assert.assertArrayEquals(expected, observed);
    }

*/


  @Test
  public void does_not_modify_s_regs() {
    Label arrays = wordData(5, 6, 7, 8, 9, 
                            1, 2, 3, 4, 7, 
                            5, 2, 7, 4, 3, 
                            1, 6, 3, 8, 4, 
                            5, 2, 7, 8, 1);

    set(s0, 1343);
    set(s1, 1557);
    set(s2, 157);
    set(s3, 17);
    set(s4, -15);
    set(s5, 167);
    set(s6, 102);
    set(s7, 100);

    run("create_default_list", arrays, 5, 5);

    Assert.assertEquals(1343, get(s0));
    Assert.assertEquals(1557, get(s1));
    Assert.assertEquals( 157, get(s2));
    Assert.assertEquals(  17, get(s3));
    Assert.assertEquals( -15, get(s4));
    Assert.assertEquals( 167, get(s5));
    Assert.assertEquals( 102, get(s6));
    Assert.assertEquals( 100, get(s7));
  }



  @Test
  public void create_list() {
    Label arrays = wordData(15, 65,  7, 68, 
                            21, 24, 93, 74, 
                            35, 23, 87, 84, 
                            41, 62, 73, 98, 
                            55, 21, 67,  8);

    int[] expected       = {15, 65,  7, 68, 
                            21, 24, 93, 74, 
                            35, 23, 87, 84, 
                            41, 62, 73, 98, 
                            55, 21, 67,  8}; 
    set(s0, 1343);
    set(s1, 1557);
    set(s2, 157);
    set(s3, 17);
    set(s4, -15);
    set(s5, 167);
    set(s6, 102);
    set(s7, 100);

    run("create_default_list", arrays, 4, 5);

    Assert.assertEquals(1343, get(s0));
    Assert.assertEquals(1557, get(s1));
    Assert.assertEquals( 157, get(s2));
    Assert.assertEquals(  17, get(s3));
    Assert.assertEquals( -15, get(s4));
    Assert.assertEquals( 167, get(s5));
    Assert.assertEquals( 102, get(s6));
    Assert.assertEquals( 100, get(s7));


    int head = get(v0);
    int[] observed = list2array( head , 20 );

    Assert.assertArrayEquals(expected, observed);
  }



  @Test
  public void test_map2d() {
    Label arrays = wordData(5, 6, 7, 8, 9,
                            1, 2, 3, 4, 7,
                            5, 2, 7, 4, 3,
                            1, 6, 3, 8, 4,
                            5, 2, 7, 8, 1);

    int[] expected       = {30, 42, 56, 72, 90,
                             2, 6, 12, 20, 56,
                            30, 6, 56, 20, 12,
                             2, 42, 12, 72, 20,
                            30, 6, 56, 72, 2};

    run("jmain", arrays, 5, 5, 0);

    int[] observed = list2array( get(v0) , 25 );

    Assert.assertArrayEquals(expected, observed);
  }



}
