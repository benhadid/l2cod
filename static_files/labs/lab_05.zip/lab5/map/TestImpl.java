import org.junit.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class TestImpl {

     int[] list2array(int head)
     {
       int[] array = new int[10];

       int i = 0;
       int node = head;

       while(node != 0)
       {
         array[i] = getWord(node);

         node  = getWord(node + 4);
         i++;
       }

       return array;
     }

    @Test
    public void map_square() {

        run("jmain", 0); // square function

        int[] expected = {81, 64, 49, 36, 25, 16, 9, 4, 1, 0};

        int head   = get(v0);
        int[] observed = list2array(head);

        Assert.assertArrayEquals(expected, observed);
    }

    @Test
    public void map_double() {

        run("jmain", 1); // double function

        int[] expected = {18, 16, 14, 12, 10, 8, 6, 4, 2, 0};

        int head   = get(v0);
        int[] observed = list2array(head);

        Assert.assertArrayEquals(expected, observed);
    }

    @Test
    public void map_half() {

        run("jmain", 2); // half function

        int[] expected = {4, 4, 3, 3, 2, 2, 1, 1, 0, 0};
 
        int head   = get(v0);
        int[] observed = list2array(head);

        Assert.assertArrayEquals(expected, observed);
    }
}
