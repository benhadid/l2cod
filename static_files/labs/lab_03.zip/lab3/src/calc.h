float calculatrice(float num1, float num2, char op);
