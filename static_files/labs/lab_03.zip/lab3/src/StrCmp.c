#include <stdlib.h>

#include "StrCmp.h"

/**
 * @brief 
 * 
 * @param s1 - pointeur sur la première chaine de caractères
 * @param s2 - pointeur sur la deuxième chaine de caractères
 * @return int  -  résultat de la comparaison  (cf. man 3 strcmp)
 */
int StrCmp(char *s1, char *s2)
{

    // VOTRE CODE ICI 
    
}
