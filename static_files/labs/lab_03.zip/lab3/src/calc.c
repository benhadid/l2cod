#include <math.h>

#include "calc.h"

/**
 * @brief Calculatrice simple
 * 
 * @param num1 -  1er  opérande
 * @param num2 -  2ème  opérande
 * @param op   -  l'un des caractères ascii {'+','-','*','/'} 
 * @return float - résultat de l'opération ! num1 op num2
 */
float calculatrice(float num1, float num2, char op)
{

    // VOTRE CODE ICI 

}

