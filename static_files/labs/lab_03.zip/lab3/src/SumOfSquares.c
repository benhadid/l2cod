#include "SumOfSquares.h"

/**
 * @brief 
 * 
 * @param count - Nombre d'éléments dans le tableau
 * @param tab - pointeur sur le tableau
 * @return unsigned int  - résultat de la somme des carrés des éléments du tableau
 */
unsigned int SumOfSquares(int count, int *tab)
{
 
   // VOTRE CODE ICI 

}

