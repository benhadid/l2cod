#include "gtest/gtest.h"

extern "C"
{
#include "SumOfSquares.h"
}

TEST(SumOfSquares, cas_0)
{       
	int result = SumOfSquares(0, NULL);
      
        EXPECT_EQ(0, result);
}

TEST(SumOfSquares, cas_1)
{
        int tab [1] = {1};

	int result = SumOfSquares(1, tab);
      
        EXPECT_EQ(1, result);
}

TEST(SumOfSquares, cas_1bis)
{
        int tab [1] = {5};

	int result = SumOfSquares(1, tab);
      
        EXPECT_EQ(25, result);
}

TEST(SumOfSquares, cas_3)
{
        int tab [3] = {1, -2, 3};
       
	int result = SumOfSquares(3, tab);
      
        EXPECT_EQ(14, result);
}

TEST(SumOfSquares, cas_3bis)
{
        int tab [3] = {1, 2, 3};
       
	int result = SumOfSquares(3, tab);
      
        EXPECT_EQ(14, result);
}

TEST(SumOfSquares, cas_7)
{
        int tab [7] = {1, -2, 3, 7, 0, -9, 12};
       
	int result = SumOfSquares(7, tab);
      
        EXPECT_EQ(288, result);
}


