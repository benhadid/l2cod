#include "gtest/gtest.h"

extern "C"
{
#include "StrCmp.h"
}

TEST(StrCmp, cas_inferieur)
{
        char s1[] = "mi";
        char s2[] = "mi-alger";

        int result = StrCmp(s1, s2);

        EXPECT_TRUE( result < 0);
}

TEST(StrCmp, cas_egal)
{
        char s1[] = "mi-alger";
        char s2[] = "mi-alger";

        int result = StrCmp(s1, s2);

        EXPECT_EQ(0, result);
}

TEST(StrCmp, cas_superieur)
{
        char s1[] = "mi-alger.lan";
        char s2[] = "mi-alger";

        int result = StrCmp(s1, s2);

        EXPECT_TRUE( result > 0);
}

TEST(StrCmp, cas_inferieur_null)
{
        char s2[] = "mi-alger";

        int result = StrCmp(NULL, s2);

        EXPECT_TRUE( result < 0);
}

TEST(StrCmp, cas_superieur_null)
{
        char s1[] = "mi-alger.lan";

        int result = StrCmp(s1, NULL);

        EXPECT_TRUE( result > 0);
}

TEST(StrCmp, cas_egal_null)
{
        int result = StrCmp(NULL, NULL);

        EXPECT_EQ(0, result);
}
