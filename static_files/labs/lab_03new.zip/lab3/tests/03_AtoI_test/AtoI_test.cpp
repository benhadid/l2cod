#include "gtest/gtest.h"

extern "C"
{
#include "AtoI.h"
}

TEST(AtoI, cas_pos)
{
        char s1[] = "153";

        int result = AtoI(s1);

        EXPECT_EQ(153, result);
}

TEST(AtoI, cas_neg)
{
        char s1[] = "-153";

        int result = AtoI(s1);

        EXPECT_EQ(-153, result);
}

