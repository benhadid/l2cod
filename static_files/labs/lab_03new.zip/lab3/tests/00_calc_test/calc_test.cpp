#include <math.h>

#include "gtest/gtest.h"

extern "C" {
#include "calc.h"
}


TEST(calculatrice, op_plus) 
{
	float result = calculatrice(15.0f, 3.0f, '+');
    EXPECT_EQ( 18.0f, result );
}

TEST(calculatrice, op_moins) 
{
	float result = calculatrice(15.0f, 3.0f, '-');
    EXPECT_EQ( 12.0f, result );
}

TEST(calculatrice, op_mult) 
{
	float result = calculatrice(15.0f, 3.0f, '*');
    EXPECT_EQ( 45.0f, result );
}

TEST(calculatrice, op_div) 
{
	float result = calculatrice(15.0f, 3.0f, '/');
    EXPECT_EQ( 5.0f, result );
}

TEST(calculatrice, op_err) 
{
	float result = calculatrice(15.0f, 3.0f, 'c');
	EXPECT_TRUE( isnan(result) );
}