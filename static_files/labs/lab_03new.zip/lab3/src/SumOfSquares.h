unsigned int SumOfSquares(int count, int *tab);
