import subprocess
import argparse
import shlex
import sys
import re

from pathlib import Path

# C/C++ comment_remover by Adnane BENHADID  # (/\*([^*]|[\r\n]|(\*+([^*/]|[\r\n])))*\*+/)|(//.*)
def comment_remover(text):
    def replacer(match):
        s = match.group(0)
        if s.startswith('/'):
            return " " # note: a space and not an empty string
        else:
            return s

    pattern = re.compile(
        r'//.*?$|/\*.*?\*/|\'(?:\\.|[^\\\'])*\'|"(?:\\.|[^\\"])*"',
        re.DOTALL | re.MULTILINE
    )
    return re.sub(pattern, replacer, text)

def check_keywords(srcfile, params):

    banned_keywords = params
    
    if len(banned_keywords) != 0:
        p = subprocess.Popen(shlex.split("cat {}".format(srcfile)), stderr=subprocess.STDOUT, stdout=subprocess.PIPE)
        source_code = p.communicate()[0].decode('utf-8')
    
        stripped_output = comment_remover(source_code)

        counter = 0

        for keyword in banned_keywords:
          if re.search("{}\s*\(.*?\)".format(keyword), stripped_output) or re.search("{}(\s+|{{)".format(keyword), stripped_output):
              if keyword == '\?':
                 print("Vous utilisez l'opérateur ternaire ?:, qui n'est pas autorisé.")
              else:
                 print("Vous utilisez le mot-clé '{}', qui n'est pas autorisé.".format(keyword))
              counter = counter + 1
              
        if counter == 0:
           print("Votre fichier source \"{}\" ne contient aucun mot-clé/opérateur interdit :) !".format(srcfile))



def main(argv):
    parser = argparse.ArgumentParser(description='Vérification de contenance de mots-clés interdits')

    parser.add_argument('-n', '--filename', help="src filename", required=True)
    parser.add_argument('-f', '--for',      help='for keyword is forbidden',    action='store_true')
    parser.add_argument('-w', '--while',    help='while keyword is forbidden',  action='store_true')
    parser.add_argument('-e', '--else',     help='else keyword is forbidden',   action='store_true')
    parser.add_argument('-s', '--switch',   help='switch keyword is forbidden', action='store_true')
    parser.add_argument('-t', '--ternary',  help='ternary operator ?: is forbidden', action='store_true')

    args = vars(parser.parse_args(argv[1:]))

    srcfile = Path(args['filename'])

    if not srcfile.is_file():
       print('\nErreur : Fichier "{}" introuvale !\n'.format(args['filename']))
       return

    params = []
    if args['for'] == True:
       params.append('for')

    if args['while'] == True:
       params.append('while')

    if args['else'] == True:
       params.append('else')

    if args['switch'] == True:
       params.append('switch')

    if args['ternary'] == True:
       params.append('\?')

    if len(params) > 0:
       check_keywords(args['filename'], params)


if __name__ == '__main__':
    main(sys.argv)
