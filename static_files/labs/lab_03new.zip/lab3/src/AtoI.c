#include "AtoI.h"

/**
 * @brief 
 * 
 * @param str - pointeur sur la chaine de caractère à convertir
 * @return int - l'entier résultat de la conversion
 */
int AtoI(char *str)
{
 
   // VOTRE CODE ICI 

}
