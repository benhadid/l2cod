int AtoI(char *tab);
