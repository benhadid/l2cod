#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "bin2int.h"

int main()
{
  char *strings[] = {"10011001", "10011101", "01011001", "00110001", "10010.01", "100+1111", "101011001", "0110000"};
  int expected[] = {153, 157, 89, 49, 18, 4, 345, 48};

  int len = (sizeof expected) / sizeof(int);

  for (int i = 0; i < len; ++i)
  {
    int value = bin2int_conversion(strings[i]);
    printf("bin2int_conversion(\'%s\')... ", strings[i]);
    if (value == expected[i])
      printf("correct\n");
    else
      printf("expected: %d, got %d\n", expected[i], value);
  }

  return 0;
}
