#include <stdio.h>
#include "bit_ops.h"

// Returns the n_th bit of x.
// You may assume that 0 <= n <= 31
bool get_bit(uint32_t x,
                 uint8_t n) {
    
    // YOUR  CODE HERE 
    
    return 0;  // you should probably modify this line as well 
}

// Sets the n-th bit of x to v.
// You may assume that 0 <= n <= 31
void set_bit(uint32_t * x,
             uint8_t n,
             bool v) {
    
    // YOUR  CODE HERE 

}

// flips the n-th bit of x.
// You may assume that 0 <= n <= 31
void flip_bit(uint32_t * x,
              uint8_t n) {
    
    // YOUR  CODE HERE 

}
