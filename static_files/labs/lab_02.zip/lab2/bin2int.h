int bin2int_conversion(char *string);
