
/**  Converts a binary string to an integer
 *   @param   string - a null terminated string of characters 
 *   @return  result - integer equivalent of input string  
 */
int bin2int_conversion(char *string)
{
   int result = -1;    /* result should contain the converted value before returning */

   /* Your code begins here */


   /* Your code ends here */
   
   return result;
}
