# include<stdint.h>
# include<stdbool.h>

uint8_t get_3_leftmost_bits(uint32_t x);
bool get_bit(uint32_t x, uint8_t n);
void set_bit(uint32_t* x, uint8_t n, bool v);
void flip_bit(uint32_t* x, uint8_t n);