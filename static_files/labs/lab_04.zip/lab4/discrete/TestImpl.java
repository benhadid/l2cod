import java.util.*;  
import org.junit.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class TestImpl {

    private Label output;

    @Before
    public void init_v0() {
        this.output = wordData(6, 61, 17, -38, 19, 42, 5);
    }

    @Test
    public void discrete_neg3() {


        run("f", -3, this.output); // f(-3)

        Assert.assertEquals(getWord(this.output, 0), get(v0));
    }

    @Test
    public void discrete_neg2() {

        run("f", -2, this.output); // f(-2) 

        Assert.assertEquals(getWord(this.output, 4), get(v0));
    }

    @Test
    public void discrete_neg1() {

        run("f", -1, this.output); // f(-1)

        Assert.assertEquals(getWord(this.output, 8), get(v0));
    }

    @Test
    public void discrete_zero() {

        run("f", 0, this.output); // f(0)

        Assert.assertEquals(getWord(this.output, 12), get(v0));
    }

    @Test
    public void discrete_pos1() {

        run("f", 1, this.output); // f(1)

        Assert.assertEquals(getWord(this.output, 16), get(v0));
    }

    @Test
    public void discrete_pos2() {

        run("f", 2, this.output); // f(2)

        Assert.assertEquals(getWord(this.output, 20), get(v0));
    }

    @Test
    public void discrete_pos3() {

        run("f", 3, output); // f(3)

        Assert.assertEquals(getWord(this.output, 24), get(v0));
    }
}
