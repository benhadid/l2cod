# include<stdint.h>
# include<stdbool.h>

bool get_bit(uint32_t x, uint8_t n);
void set_bit(uint32_t* x, uint8_t n, bool v);
void flip_bit(uint32_t* x, uint8_t n);