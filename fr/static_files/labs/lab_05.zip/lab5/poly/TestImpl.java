import org.junit.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;


public class TestImpl {

    @Before
     public void init_v0() {
     set(v0, -1);
    }

    @Test
    public void test_poly_zero() {
        run("poly", 0);
        Assert.assertEquals(1, get(v0));
    }

    @Test
    public void test_poly_one() {
        run("poly", 1);
        Assert.assertEquals(3, get(v0));
    }

    @Test
    public void test_poly_minus_one() {
        run("poly", -1);
        Assert.assertEquals(1, get(v0));
    }

    @Test
    public void test_poly_positif() {
        run("poly", 5);
        Assert.assertEquals(751, get(v0));
    }

    @Test
    public void test_poly_negatif() {
        run("poly", -3);
        Assert.assertEquals(55, get(v0));
    }

    @Test
    public void does_not_modify_s_regs() {
      set(s0, 1343);
      set(s1, 1557);
      run("poly", 2);
      Assert.assertEquals(1343, get(s0));
      Assert.assertEquals(1557, get(s1));
    }
}
