# Lab 5 - Appel de foncton dans MIPS
