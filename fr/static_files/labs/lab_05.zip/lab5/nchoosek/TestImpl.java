import org.junit.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;


public class TestImpl {

    @Before
     public void init_data() {        
        set(v0, -1);
    }

    @Test
    public void test_nchoosek_4_0() {
        run("nchoosek", 4, 0);
        Assert.assertEquals(1, get(v0));
    }

    @Test
    public void test_nchoosek_4_1() {
        run("nchoosek", 4, 1);
        Assert.assertEquals(4, get(v0));
    }

    @Test
    public void test_nchoosek_4_2() {
        run("nchoosek", 4, 2);
        Assert.assertEquals(6, get(v0));
    }

    @Test
    public void test_nchoosek_4_3() {
        run("nchoosek", 4, 3);
        Assert.assertEquals(4, get(v0));
    }

    @Test
    public void test_nchoosek_4_4() {
        run("nchoosek", 4, 4);
        Assert.assertEquals(1, get(v0));
    }

    @Test
    public void test_nchoosek_4_5() {
        run("nchoosek", 4, 5);
        Assert.assertEquals(0, get(v0));
    }


    @Test
    public void does_not_modify_s_regs() {
      set(s0, 1343);
      set(s1, 1557);
      set(s2, 1901);
      run("nchoosek", 4, 2);
      Assert.assertEquals(1343, get(s0));
      Assert.assertEquals(1557, get(s1));
      Assert.assertEquals(1901, get(s2));
    }
}
