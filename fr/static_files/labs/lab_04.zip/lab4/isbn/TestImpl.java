import org.junit.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class TestImpl {

  @Test
  public void isbn1() {

    Label str1 = asciiData(true, "3-598-21508-8");

    set(v0, 1111);

    run("is_valid", str1);
    Assert.assertEquals(  1, get(v0) );
  }
  @Test
  public void isbn2() {

    Label str2 = asciiData(true, "3-598-21508-9");

    set(v0, 2222);

    run("is_valid", str2);
    Assert.assertEquals(  0, get(v0) );
  }

  @Test
  public void isbn3() {

    Label str3 = asciiData(true, "3-598-21507-X");
    
    set(v0, 3333);

    run("is_valid", str3);
    Assert.assertEquals(  1, get(v0) );
  }

  @Test
  public void isbn12() {

    Label str12 = asciiData(true, "00");
    
    set(v0, 1212);

    run("is_valid", str12);
    Assert.assertEquals(  0, get(v0) );
  }
}
