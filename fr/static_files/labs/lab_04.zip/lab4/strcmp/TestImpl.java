import org.junit.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class TestImpl {

  @Test
  public void StrCmp_inf() {

    Label str1 = asciiData(true, "mi");
    Label str2 = asciiData(true, "mi-alger");
    
    set(v0, 0);

    run("StrCmp", str1, str2);
    Assert.assertTrue( 0 > get(v0) );
  }

  @Test
  public void StrCmp_equal() {

    Label str1 = asciiData(true, "mi-alger");
    Label str2 = asciiData(true, "mi-alger");

    set(v0, 3343);

    run("StrCmp", str1, str2);
    Assert.assertEquals( 0, get(v0) );
  }

  @Test
  public void StrCmp_sup() {

    Label str1 = asciiData(true, "mi-alger.lan");
    Label str2 = asciiData(true, "mi-alger");

    set(v0, 0);

    run("StrCmp", str1, str2);
    Assert.assertTrue( 0 < get(v0) );
  }
}
