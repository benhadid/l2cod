import org.junit.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class TestImpl {

  @Before
  public void init_v0() {
   set(v0, -1);
  }

  @Test
  public void SumOfSquares_zero() {
    Label array = wordData(0);
    run("SumOfSquares", 1, array);
    Assert.assertEquals(0, get(v0));
  }

  @Test
  public void SumOfSquares_zeros() {
    Label array = wordData(0, 0, 0, 0, 0, 0, 0, 0);
    run("SumOfSquares", 8, array);
    Assert.assertEquals(0, get(v0));
  }

  @Test
  public void SumOfSquares_one() {
    Label array = wordData(1);
    run("SumOfSquares", 1, array);
    Assert.assertEquals(1, get(v0));
  }

  @Test
  public void SumOfSquares_ones() {
    Label array = wordData(1, 1, 1, 1, 1, 1, 1, 1);
    run("SumOfSquares", 8, array);
    Assert.assertEquals(8, get(v0));
  }

  @Test
  public void SumOfSquares_any1() {

    Label array = wordData(1, 2, 4, 9, 16, 22, 18, 14);
    run("SumOfSquares", 8, array);
    Assert.assertEquals(1362, get(v0));
  }

  @Test
  public void SumOfSquares_any2() {

    Label array = wordData(1, 2, -4, 9, -16, 22, -18, 14);
    run("SumOfSquares", 8, array);
    Assert.assertEquals(1362, get(v0));
  }  
}

