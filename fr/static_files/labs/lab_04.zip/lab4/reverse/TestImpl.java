import org.junit.*;

import edu.gvsu.mipsunit.munit.MUnit;
import static edu.gvsu.mipsunit.munit.MUnit.*;
import static edu.gvsu.mipsunit.munit.MUnit.Register.*;

public class TestImpl {

    @Test
    public void reversePartialListEven() {
        MUnit.Label array1 = wordData(11, 12, 13, 14, 15, 16, 17, 18, 19, 20);
        run("reverse", array1, 6);
        int[] expected = {16, 15, 14, 13, 12, 11, 17};
        int[] observed = getWords(array1, 0, 7);
        Assert.assertArrayEquals(expected, observed);
        Assert.assertTrue(noOtherMemoryModifications());
    }

    @Test
    public void reversePartialListOdd() {
        MUnit.Label array1 = wordData(21, 22, 23, 24, 25, 26, 27, 28, 29, 30);
        run("reverse", array1, 7);
        int[] expected = {27, 26, 25, 24, 23, 22, 21, 28};
        int[] observed = getWords(array1, 0, 8);
        Assert.assertArrayEquals(expected, observed);
        Assert.assertTrue(noOtherMemoryModifications());
    }

   @Test
   public void does_not_modify_s_regs() {
       MUnit.Label array1 = wordData(11, 12, 13, 14, 15, 16, 17, 18, 19, 20);

       set(s0, 1343);
       set(s1, 1557);
       set(s2, 157);
       set(s3, 17);
       set(s4, -15);
       set(s5, 167);
       set(s6, 102);
       set(s7, 100);

       run("reverse", array1, 6);

       Assert.assertEquals(1343, get(s0));
       Assert.assertEquals(1557, get(s1));
       Assert.assertEquals( 157, get(s2));
       Assert.assertEquals(  17, get(s3));
       Assert.assertEquals( -15, get(s4));
       Assert.assertEquals( 167, get(s5));
       Assert.assertEquals( 102, get(s6));
       Assert.assertEquals( 100, get(s7));
   }

/*
    @Test
    public void verifyThatThisFails() {
        MUnit.Label array1 = wordData(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        run("reverse", array1, 6);
        Assert.assertArrayEquals(new int[]{6, 5, 4, 3, 2}, getWords(array1, 0, 5));
        // This should fail because position 5 was modified, but not checked.
        Assert.assertFalse("This should be false!", noOtherMemoryModifications());
    }
*/
}
