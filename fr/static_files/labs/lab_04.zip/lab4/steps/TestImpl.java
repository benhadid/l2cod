import org.junit.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class TestImpl {

@Before
  public void init_v0() {
   set(v0, 3020);
  }

  @Test
  public void conjucture_one() {
    run("steps", 16);
    Assert.assertEquals(4, get(v0));
  }

  @Test
  public void conjucture_two() {
    run("steps", 12);
    Assert.assertEquals(9, get(v0));
  }
}
