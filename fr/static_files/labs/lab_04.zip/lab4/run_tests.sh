#!/bin/bash

#https://en.wikipedia.org/wiki/ANSI_escape_code
CO='\033[0;32m'
NC='\033[0m'

for d in */ ; do 
   RUNNER="$d/impl_runner.s"

   echo -e "${CO}\nTest de votre implementation dans $d${NC}" 

   if [ -f ${RUNNER} ]; then
       java -jar munit.jar ${RUNNER} "$d/impl.s" "$d/TestImpl.class"
   else
       java -jar munit.jar "$d/impl.s" "$d/TestImpl.class"
   fi 

done
