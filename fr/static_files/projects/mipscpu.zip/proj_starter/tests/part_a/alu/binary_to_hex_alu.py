#!/usr/bin/env python3

from __future__ import print_function

import sys

def main(args):
	file = open(args[1])
	lines = [l for l in file.readlines()]
	def mapper(string):
		try:
			return hex(int(string, 2))[2:]
		except Exception:
			return 'x'
	results = []
	for l in lines:
		hexes = list(map(mapper, l.split()))
		zero      = ''.join(hexes[:1])
		op        = ''.join(hexes[1:3])
		aluOutput = ''.join(hexes[3:11])
		aluSel = ''.join(hexes[11:12])
		inputA = ''.join(hexes[12:20])
		inputB = ''.join(hexes[20:28])
		result = [op, aluSel, inputA, inputB, aluOutput, zero]
		results.append(result)
	print('Op#\tALUSel\tInputA\t\tInputB\t\tALU_Output\tzero')
	for r in results:
		string = '\t'.join(r)
		print(string)

if __name__ == '__main__':
	main(sys.argv)
